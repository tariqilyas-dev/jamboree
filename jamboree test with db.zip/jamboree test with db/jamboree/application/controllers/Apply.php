<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Apply extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Kolkata');
        define('created_on', date('Y-m-d H:i:s'));
    } 

	public function register()
	{	
		$username = $_POST['username'];
		$password = $_POST['password'];

    	$insertUser = array(
        'user_name' => $username,
        'password' => $password,
        'user_created_on' => created_on,
    	);


    	$query = $this->db->select('user_name')->where('user_name', $username)->from('user')->get();
        $result = $query->row();

        if(!empty($result)) {
        $existing_user_name = $result->user_name;
  		
        if ($existing_user_name == $username) {
           $this->session->set_flashdata('errorregistration',"This user name is already exists");
           return redirect(base_url("register"), "refresh");
        }
    	}

    	$this->db->insert('user', $insertUser);
        
        $user_id = $this->db->insert_id();

        if(!empty($user_id)){
        	// exit;
        	$this->session->set_flashdata('successregistration',"Registration of user Succesfully. You can login!!");
        	return redirect(base_url(""), "refresh");
        }
	
	}


	public function login()
	{	
		$username = $_POST['username'];
		$password = $_POST['password'];
    	$query = $this->db->select('user_name,password')->where('user_name', $username)->where('password', $password)->from('user')->get();
        $result = $query->row();
        if(!empty($result)){
           $this->session->set_userdata('user_name',$result->user_name);
           return redirect(base_url("home"), "refresh");
        }
        else{
        	$this->session->set_flashdata('errorlogin',"Login credentials not matched!!");
        	return redirect(base_url(""), "refresh");
        }
	
	}


	public function task()
	{	
		$task_name = $_POST['task_name'];
    	$insertTask = array(
        'task_name' => $task_name,
        'task_created_on' => created_on,
    	);

    	$this->db->insert('task', $insertTask);
        
        $task_id = $this->db->insert_id();
        if(!empty($task_id)){
        	$this->session->set_flashdata('successtask',"Task created Succesfully.");
        	return redirect(base_url("viewtask"), "refresh");
        }
	
	}


	public function edittask()
	{	
		$task_id = $_POST['task_id'];
		$task_name = $_POST['task_name'];

    	$updateTask = array(
        'task_name' => $task_name,
        'task_updated_on' => created_on,
    	);

    	$updateTaskflag = $this->db->where('task_id', $task_id)->update('task', $updateTask);

        if(!empty($updateTaskflag)){
        	$this->session->set_flashdata('successtaskupdate',"Task updated Succesfully.");
        	return redirect(base_url("viewtask"), "refresh");
        }else{
        	$this->session->set_flashdata('errortaskupdate',"Unable to Task.");
        	return redirect(base_url("viewtask"), "refresh");
        }
	
	}

	
}
