<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {
	public function register()
	{
		$this->load->view('register.php');
	}
	
	public function login()
	{
		$this->load->view('login.php');
	}
}
