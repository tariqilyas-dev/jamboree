<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HomeController extends CI_Controller {
	public function home()
	{
		$this->load->view('index.php');
	}

	public function viewtask()
	{	
		$query = $this->db->select('*')->from('task')->where('task_active', 1)->get();
        $result['data'] = $query->result_array();
        if(!empty($result['data'])){
		$this->load->view('viewtask.php',$result);
		}
		else{
		$this->session->set_flashdata('errorview',"No Record available");
        $this->load->view('viewtask.php');
		}
	}

	public function edittask($task_id)
	{	
		$id = base64_decode($task_id);
		$query = $this->db->select('*')->where('task_id', $id)->from('task')->get();
        $result['data'] = $query->result_array();
        $this->load->view('edittask.php',$result);
	}

	public function deletetask($task_id)
	{	
		$id = base64_decode($task_id);

		$update_task = $this->db->set('task_active', 0)->where('task_id', $id)->update('task');
		if(!empty($update_task)){
		$this->session->set_flashdata('msgtaskactive',"Soft deleted task successfully.");
		return redirect(base_url("viewtask"), "refresh");
		}
		else{
		$this->session->set_flashdata('msgtaskactive',"Unable to delete task.");
		return redirect(base_url("viewtask"), "refresh");
		}
	}

	public function editstatus($task_id)
	{	
       	$id = base64_decode($task_id);
		$query = $this->db->select('task_status')->where('task_id', $id)->from('task')->get();
        $result = $query->row();
        $task_value =  $result->task_status;
        if ($task_value == 0) {
        	$change_task_value = 1;
        }
        if ($task_value == 1) {
        	$change_task_value = 0;
        }


		$update_task = $this->db->set('task_status', $change_task_value)->where('task_id', $id)->update('task');
		if(!empty($update_task)){
		$this->session->set_flashdata('msgtaskstatus',"Task status change successfully.");
		return redirect(base_url("viewtask"), "refresh");
		}
		else{
		$this->session->set_flashdata('msgtaskstatus',"Unable to update task status.");
		return redirect(base_url("viewtask"), "refresh");
		}
	}


}
