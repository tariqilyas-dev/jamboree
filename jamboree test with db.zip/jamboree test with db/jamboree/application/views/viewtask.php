<?php  
$user_name =  $this->session->userdata('user_name'); 
$successtask =  $this->session->flashdata('successtask');
$errorview =  $this->session->flashdata('errorview');
$msgtaskactive =  $this->session->flashdata('msgtaskactive');
$msgtaskstatus =  $this->session->flashdata('msgtaskstatus');
$successtaskupdate =  $this->session->flashdata('successtaskupdate');

$this->load->view("include/header.php");
?>


<center>
<?php
if (isset($successtask)){
?>
<b><span style="color: green;" onclick="this.parentElement.style.display='none';"> <?php echo $successtask; ?> <em class="close-me">&times;</em></span> 
</b>
<?php
 }
$this->session->unset_userdata('successtask');

if (isset($errorview)){
?>
<b><span style="color: red;" onclick="this.parentElement.style.display='none';"> <?php echo $errorview; ?> <em class="close-me">&times;</em></span> 
</b>
<?php
 }
 $this->session->unset_userdata('errorview');


if (isset($msgtaskactive)){
?>
<b><span style="color: green;" onclick="this.parentElement.style.display='none';"> <?php echo $msgtaskactive; ?> <em class="close-me">&times;</em></span> 
</b>
<?php
 }
 $this->session->unset_userdata('msgtaskactive');


if (isset($msgtaskstatus)){
?>
<b><span style="color: green;" onclick="this.parentElement.style.display='none';"> <?php echo $msgtaskstatus; ?> <em class="close-me">&times;</em></span> 
</b>
<?php
 }
 $this->session->unset_userdata('msgtaskstatus');

if (isset($successtaskupdate)){
?>
<b><span style="color: green;" onclick="this.parentElement.style.display='none';"> <?php echo $successtaskupdate; ?> <em class="close-me">&times;</em></span> 
</b>
<?php
 }
 $this->session->unset_userdata('successtaskupdate');

?>
</center>

<br/><br/><br/>
<div class="container">
  <h2>Task Data</h2>            
  <table class="table table-bordered" id="myTable">
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Task Name</th>
        <th>Task created on</th>
        <th>Task updated on</th>
        <th>Change Status</th>
        <th>Task Update</th>
        <th>Task Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($data as $value) {?>
      <tr>
        <td><?php echo $value['task_id']; ?></td>
        <td><?php echo $value['task_name']; ?></td>
        <td><?php echo $value['task_created_on']; ?></td>
        <td><?php echo $value['task_updated_on']; ?></td>
        <td>
          <a id="status" class="btn btn-primary btn-sm" href="<?= base_url('editstatus/' . base64_encode($value["task_id"])) ?>">
             <?php if($value['task_status']==1){echo "completed";}else{ echo "Incompleted";} ?>
         </a>
        </td>
        <td>
        <a id="editbutton" class="btn btn-primary btn-sm" href="<?= base_url('edittask/' . base64_encode($value["task_id"])) ?>">Update</a>
        </td>
        <td>
        <a id="deletebutton" class="btn btn-primary btn-sm" href="<?= base_url('deletetask/' . base64_encode($value["task_id"])) ?>">Delete</a>
        </td>
      </tr>
      <?php
      } 
      ?>
    </tbody>
  </table>
</div>


<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>