<?php 
$user_name =  $this->session->userdata('user_name'); 

$this->load->view("include/header.php");
?>


<body>
<div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">

        <h2 class="text-center text-dark mt-5">Create Task</h2>
        <div class="card my-5">


          <form id="card-body cardbody-color p-lg-5" action="<?= base_url('Apply/task'); ?>" method="post" role="form" autocomplete="off">
            <div class="mb-3">
              <input type="text" class="form-control" id="task_name" name="task_name" minlength="3" maxlength="50" aria-describedby="emailHelp" placeholder="Task Name" required>
            </div>
            <div class="text-center"><button type="submit" class="btn btn-color px-5 mb-5 w-100">Submit</button></div>
           
          </form>
        </div>

      </div>
    </div>
  </div>
</body>
</html>

